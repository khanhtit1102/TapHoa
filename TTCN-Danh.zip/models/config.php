private $conn;
		public function __construct()
		{
			$host = "localhost";
			$username = "root";
			$password = "";
			$database = "db_shoptaphoa";

			$this->conn= new mysqli($host, $username, $password, $database) or die('Loi ket noi');
			$this->conn->set_charset("UTF8");
			//$this->conn->close();
		}