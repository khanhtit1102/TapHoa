<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>404 - ERROR - Huyền Trang Book</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="../css/webstyle.css">
	<link rel="stylesheet" href="../css/font-awesome.css">
	<!-- 	<script src="ckeditor/ckeditor.js"></script> -->
</head>
<body>
	<section class="container" align="center">
		<br><br><br><br>
		<h1>OPP! 404 - ERROR</h1><br><br><br>
		<h1>SORRY, THAT PAGE DOSEN'T EXIST</h1><br><br><br><br>
		<a href="../index.php"><button type="button" class="btn btn-danger">BACK TO HOME PAGE</button></a>
	</section>
	<script src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/script.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>