<div class="footer-area">
    <p>Bản quyền © Phạm Công Danh trường ĐH CNTT&TT Thái Nguyên.</p>
</div>