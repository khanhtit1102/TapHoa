<div id="main-menu" class="mobile-sidebar no-scrollbar mfp-hide">
    <div class="sidebar-menu no-scrollbar ">
        <ul class="nav nav-sidebar  nav-vertical nav-uppercase">
            <li class="header-block">
                <div class="header-block-block-1">
                    <ul class="sidebar-wrapper ul-reset">
                        <aside id="woocommerce_product_categories-2" class="widget woocommerce widget_product_categories"><span class="widget-title "><span>Danh mục sản phẩm</span></span>
                            <div class="is-divider small"></div>
                            <ul class="product-categories">
                                <li class="cat-item cat-item-124"><a href="?action=dienthoai">Điện thoại</a>
                                </li>
                                <li class="cat-item cat-item-125"><a href="?action=laptop">Laptop</a>
                                </li>
                                <li class="cat-item cat-item-129"><a href="?action=tablet">Tablet</a>
                                </li>
                                <li class="cat-item cat-item-97"><a href="?action=phukien">Phụ kiện</a>
                                </li>
                                <li class="cat-item cat-item-127"><a href="?action=dongho">Đồng hồ</a>
                                </li>
                            </ul>
                        </aside>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</div>