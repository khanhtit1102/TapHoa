<div class="section-content relative">
    <div class="row" id="row-686091080">
        <div class="col div-no-padding small-12 large-12">
            <div class="col-inner">
                <div class="menu-header hide-for-small">
                    <div class="menu-menu-chinh-container">
                        <ul id="menu-menu-chinh" class="menu">
                            <li id="menu-item-1180" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-163 current_page_item menu-item-1180"><a href="index.php" aria-current="page">Trang chủ</a>
                            </li>
                            <li id="menu-item-1181" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1181"><a href="#">Sản phẩm</a>
                                <!-- <ul class="sub-menu">
                                    <li id="menu-item-2439" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2439"><a href="">Các loại đồ uống</a>
                                    </li>
                                    <li id="menu-item-2440" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2440"><a href="#">Các loại đồ ăn nhanh</a>
                                    </li>
                                    <li id="menu-item-2441" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2441"><a href="#">Các loại đồ ăn lạnh</a>
                                    </li>
                                    <li id="menu-item-2442" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2442"><a href="#">Thực phẩm khô
                                    </li>
                                    <li id="menu-item-2443" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2443"><a href="#">Thực phẩm đóng hộp</a>
                                    </li>
                                    <li id="menu-item-2443" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2443"><a href="#">Gia vị</a>
                                    </li>
                                    <li id="menu-item-2443" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-2443"><a href="#">Lương thực</a>
                                    </li>
                                </ul> -->
                            </li>
                            <li id="menu-item-1182" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1182"><a href="index.php?action=gioithieu">Giới thiệu</a>
                            </li>
                            <li id="menu-item-1183" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1183"><a href="index.php?action=gioithieu">Hình thức thanh toán</a>
                            </li>
                            <!-- <li id="menu-item-1184" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1184"><a href="#">Trả góp</a>
                            </li>
                            <li id="menu-item-1197" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1197"><a href="#">Mua hàng từ xa</a>
                            </li>
                            <li id="menu-item-1198" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1198"><a href="#">Chính sách bảo hành</a>
                            </li> -->
                        </ul>
                    </div>
                </div>
                <div class="slider-wrapper relative" id="slider-1081181132">
                    <div class="slider slider-nav-circle slider-nav-large slider-nav-light slider-style-normal" data-flickity-options='{
                                        "cellAlign": "center",
                                        "imagesLoaded": true,
                                        "lazyLoad": 1,
                                        "freeScroll": false,
                                        "wrapAround": true,
                                        "autoPlay": 6000,
                                        "pauseAutoPlayOnHover" : true,
                                        "prevNextButtons": true,
                                        "contain" : true,
                                        "adaptiveHeight" : true,
                                        "dragThreshold" : 10,
                                        "percentPosition": true,
                                        "pageDots": true,
                                        "rightToLeft": false,
                                        "draggable": true,
                                        "selectedAttraction": 0.1,
                                        "parallax" : 0,
                                        "friction": 0.6        }'>

                        <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1355958151">
                            <div data-animate="bounceInRight">
                                <div class="img-inner image-cover dark" style="padding-top:304px;">
                                    <img width="300" height="149" src="img/slider_1.jpg" class="attachment-original size-original" alt="" sizes="(max-width: 300px) 100vw, 300px" />
                                </div>
                            </div>
                            <style scope="scope">
                                #image_1355958151 {
                                    width: 12%;
                                }
                            </style>
                        </div>
                        <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1355958151">
                            <div data-animate="bounceInRight">
                                <div class="img-inner image-cover dark" style="padding-top:304px;">
                                    <img width="300" height="149" src="img/slider_2.jpg" class="attachment-original size-original" alt="" sizes="(max-width: 300px) 100vw, 300px" />
                                </div>
                            </div>
                            <style scope="scope">
                                #image_1355958151 {
                                    width: 12%;
                                }
                            </style>
                        </div>
                        <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1355958151">
                            <div data-animate="bounceInRight">
                                <div class="img-inner image-cover dark" style="padding-top:304px;">
                                    <img width="300" height="149" src="img/slider_3.jpg" class="attachment-original size-original" alt="" sizes="(max-width: 300px) 100vw, 300px" />
                                </div>
                            </div>
                            <style scope="scope">
                                #image_1355958151 {
                                    width: 12%;
                                }
                            </style>
                        </div>
                    </div>

                    <div class="loading-spin dark large centered"></div>

                    <style scope="scope">
                    </style>
                </div>
                <!-- .ux-slider-wrapper -->


            </div>
        </div>

        <style scope="scope">
            #row-686091080 > .col > .col-inner {
                padding: 0px 0px 0px 0px;
            }
        </style>
    </div>
</div>