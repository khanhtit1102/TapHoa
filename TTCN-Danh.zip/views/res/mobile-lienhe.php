<div class="ppocta-ft-fix show-for-small">

    <div id="messengerButton"> <a href="https://www.messenger.com/t/hauhomhinh97" target="_blank"><i></i></a>
    </div>

    <div id="zaloButton"> <a href="http://zalo.me/0964003047 " target="_blank"><i></i></a>
    </div>

    <div id="callNowButton"> <a href="tel:0964003047"><i></i></a>
        <a href="tel: 0969263879 " class="txt"></a>
    </div>

</div>
<div id="gopy"> <a href="#gop-y"><i class="fa fa-envelope-o" aria-hidden="true"></i><span>Tư vấn</span></a>
</div>
<div id="gop-y" class="lightbox-by-id lightbox-content mfp-hide lightbox-white " style="max-width:650px ;padding:20px">
    <div role="form" class="wpcf7" id="wpcf7-f5-o1" lang="vi" dir="ltr">
        <div class="screen-reader-response"></div>
        <form action="/#wpcf7-f5-o1" method="post" class="wpcf7-form" novalidate="novalidate">
            <div style="display: none;">
                <input type="hidden" name="_wpcf7" value="5" />
                <input type="hidden" name="_wpcf7_version" value="5.1.4" />
                <input type="hidden" name="_wpcf7_locale" value="vi" />
                <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f5-o1" />
                <input type="hidden" name="_wpcf7_container_post" value="0" />
            </div>
            <div class="form-gui-di">
                <h3>Vui lòng nhập thông tin, chúng tôi sẽ liên lạc lại tư vấn miễn phí cho quý vị </h3>
                <p>
                    <label> Họ tên
                        <br />
                        <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </label>
                </p>
                <p>
                    <label>Email
                        <br />
                        <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </label>
                </p>
                <p>
                    <label>Số điện thoại
                        <br />
                        <span class="wpcf7-form-control-wrap your-phone"><input type="tel" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" /></span> </label>
                </p>
                <p>
                    <label>Sản phẩm, nội dung quý vị quan tâm cần tư vấn chi tiết
                        <br />
                        <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </label>
                </p>
                <p>
                    <input type="submit" value="Gửi đi" class="wpcf7-form-control wpcf7-submit" />
                </p>
            </div>
            <div class="wpcf7-response-output wpcf7-display-none"></div>
        </form>
    </div>
</div>