<footer id="footer" class="footer-wrapper">


    <!-- FOOTER 1 -->
    <div class="footer-widgets footer footer-1">
        <div class="row large-columns-1 mb-0">
            <div id="text-9" class="col pb-0 widget widget_text">
                <div class="textwidget">
                    <br />
                    <section class="section" id="section_1706361234">
                        <div class="bg section-bg fill bg-fill  bg-loaded"></div>
                        <p>
                            <!-- .section-bg -->
                        </p>
                        <div class="section-content relative">
                            <div class="row" id="row-1393911683">
                                <div class="col medium-3 small-12 large-3">
                                    <div class="col-inner">
                                        <h3 class="footer-title">GIỚI THIỆU CÔNG TY</h3>
                                        <ul class="sidebar-wrapper ul-reset">
                                            <div id="nav_menu-5" class="col pb-0 widget widget_nav_menu">
                                                <div class="menu-menu-gioi-thieu-container">
                                                    <ul id="menu-menu-gioi-thieu" class="menu">
                                                        <li id="menu-item-975" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-975"><a href="?action=gioithieu">Hướng dẫn mua hàng</a>
                                                        </li>
                                                        <li id="menu-item-974" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-974"><a href="?action=gioithieu">Hướng dẫn thanh toán</a>
                                                        </li>
                                                        <li id="menu-item-973" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-973"><a href="?action=gioithieu">Chính sách bảo mật thông tin</a>
                                                        </li>
                                                        <li id="menu-item-971" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-971"><a href="?action=gioithieu">Chính sách bảo hành</a>
                                                        </li>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col medium-4 small-12 large-4">
                                    <div class="col-inner">
                                        <h3 class="footer-title">THÔNG TIN LIÊN HỆ</h3>
                                        <p>&#8211; Hotline: <strong>0987.223.452</strong> </p>
                                        <p>&#8211; Địa chỉ: <strong>Trường Công Nghệ Thông Tin & Truyền Thông Thái Nguyên</strong>
                                        </p>
                                        <p>&#8211; Giờ làm việc: (6h00 &#8211; 23H00 | tất cả các ngày trong tuần)</p>
                                    </div>
                                </div>
                                <div class="col medium-3 small-12 large-3">
                                    <div class="col-inner">
                                        <h3 class="footer-title">TÀI KHOẢN NGÂN HÀNG</h3>
                                        <!-- <p>CHỦ TÀI KHOẢN: ĐINH MẠNH THANH</p>
                                        <p>&#8211; <strong>Vietcombank Thành Công:</strong> 045105345354421</p>
                                        <p>&#8211; <strong>Viettinbank:</strong> 1050343446359</p>
                                        <p>&#8211; <strong>Agribank Hà Thành:</strong> 130343440059</p>
                                        <p>&#8211; <strong>BIDV:</strong> 26810000168316</p>
                                        <p>&#8211; <strong>Teckcombank:</strong> 19026324447019</p>
                                        <p>&#8211; <strong>ACB:</strong> 138014249</p> -->
                                    </div>
                                </div>
                                <div class="col medium-2 small-12 large-2">
                                    <div class="col-inner">
                                        <div class="img has-hover x md-x lg-x y md-y lg-y" id="image_1408912743">
                                            <div class="img-inner dark">
                                                <img width="288" height="183" src="img/include/visa.png" class="attachment-large size-large" sizes="(max-width: 288px) 100vw, 288px" />
                                            </div>
                                            <style scope="scope">
                                                <p>#image_1408912743 {
                                                    width: 100%;
                                                }
                                            </style>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p>
                            <!-- .section-content -->
                        </p>
                        <style scope="scope">
                            <p>#section_1706361234 {
                                padding-top: 0px;
                                padding-bottom: 0px;
                            }
                        </style>
                    </section>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- footer 1 -->


    <!-- FOOTER 2 -->



    <div class="absolute-footer dark medium-text-center text-center">
        <div class="container clearfix">


            <div class="footer-primary pull-left">
                <div class="copyright-footer">
                    <p>Bản quyền © Phạm Công Danh trường ĐH CNTT&TT Thái Nguyên.
                    </p>
                </div>
            </div>
            <!-- .left -->
        </div>
        <!-- .container -->
    </div>
    <!-- .absolute-footer -->
    <a href="#top" class="back-to-top button icon invert plain fixed bottom z-1 is-outline circle" id="top-link">↑ </a>

</footer>