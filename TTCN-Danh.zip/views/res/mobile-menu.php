<div class="div-menu show-for-small">
    <ul class="sidebar-wrapper ul-reset div-menu-mobile show-for-small">
        <li id="woocommerce_product_categories-3" class="widget woocommerce widget_product_categories">
            <ul class="product-categories">
                <li class="cat-item cat-item-124"><a href="?action=thucpham">Điện thoại</a>
</li>
<li class="cat-item cat-item-125"><a href="?action=hoamypham">Laptop</a>
</li>
<li class="cat-item cat-item-129"><a href="?action=khangiay">Tablet</a>
</li>
<li class="cat-item cat-item-97"><a href="?action=docanhan">Phụ kiện</a>
</li>
<li class="cat-item cat-item-127"><a href="?action=thecao">Đồng hồ</a>
</li>
</ul>
</li>
</ul>
</div>