<div class="section-content relative">

    <div class="row row-sp-5" id="row-937472715">
        <div class="col div-san-pham small-12 large-12">
            <div class="col-inner text-left" style="background-color:rgb(255, 255, 255);padding:0px 0px 0px 0px;">
                <div class="row row-sp-noi-bat" id="row-735588711">
                    <div class="col title-danh-muc col-sp-noi-bat small-12 large-12" data-animate="fadeInDown">
                        <div class="col-inner">
                            <div class="row" id="row-2056359758">
                                <div class="col div-no-padding medium-8 small-12 large-8">
                                    <div class="col-inner">
                                        <div class="video video-fit mb" style="padding-top:56.25%;">
                                            <p>
                                                <iframe width="1020" height="574" src="https://www.youtube.com/embed/AEkcBgpDt-I" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                                                </iframe>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col div-tin-tuc div-no-padding medium-4 small-12 large-4">
                                    <div class="col-inner">
                                        <div class="row large-columns-1 medium-columns-1 small-columns-1 row-xsmall">
                                            <div class="col post-item">
                                                <div class="col-inner">
                                                    <a href="#" class="plain">
                                                        <div class="box box-vertical box-text-bottom box-blog-post has-hover">
                                                            <div class="box-image" style="width:26%;">
                                                                <div class="image-cover" style="padding-top:56.25%;">
                                                                    <img width="640" height="400" src="img/new/tong-hop-6-loai-thuc-pham-tot-cho-phoi-co-the-ban-chua-biet-201910031631114959-640x400.jpg" class="attachment-medium size-medium wp-post-image" alt="" sizes="(max-width: 640px) 100vw, 640px" /> </div>
                                                            </div>
                                                            <!-- .box-image -->
                                                            <div class="box-text text-left is-small">
                                                                <div class="box-text-inner blog-post-inner">
                                                                    <h5 class="post-title is-large ">Bổ sung 6 loại thực phẩm, gia vị này vào thực đơn để thanh lọc, giải độc cho phổi</h5>
                                                                    <div class="is-divider"></div>
                                                                </div>
                                                                <!-- .box-text-inner -->
                                                            </div>
                                                            <!-- .box-text -->
                                                        </div>
                                                        <!-- .box -->
                                                    </a>
                                                    <!-- .link -->
                                                </div>
                                                <!-- .col-inner -->
                                            </div>
                                            <!-- .col -->
                                            <div class="col post-item">
                                                <div class="col-inner">
                                                    <a href="#" class="plain">
                                                        <div class="box box-vertical box-text-bottom box-blog-post has-hover">
                                                            <div class="box-image" style="width:26%;">
                                                                <div class="image-cover" style="padding-top:56.25%;">
                                                                    <img width="640" height="400" src="img/new/tong-hop-6-loai-thuc-pham-tot-cho-phoi-co-the-ban-chua-biet-201910031631114959-640x400.jpg" class="attachment-medium size-medium wp-post-image" alt="" sizes="(max-width: 640px) 100vw, 640px" /> </div>
                                                            </div>
                                                            <!-- .box-image -->
                                                            <div class="box-text text-left is-small">
                                                                <div class="box-text-inner blog-post-inner">
                                                                    <h5 class="post-title is-large ">Bổ sung 6 loại thực phẩm, gia vị này vào thực đơn để thanh lọc, giải độc cho phổi</h5>
                                                                    <div class="is-divider"></div>
                                                                </div>
                                                                <!-- .box-text-inner -->
                                                            </div>
                                                            <!-- .box-text -->
                                                        </div>
                                                        <!-- .box -->
                                                    </a>
                                                    <!-- .link -->
                                                </div>
                                                <!-- .col-inner -->
                                            </div>
                                            <!-- .col -->
                                            <div class="col post-item">
                                                <div class="col-inner">
                                                    <a href="#" class="plain">
                                                        <div class="box box-vertical box-text-bottom box-blog-post has-hover">
                                                            <div class="box-image" style="width:26%;">
                                                                <div class="image-cover" style="padding-top:56.25%;">
                                                                    <img width="640" height="400" src="img/new/tong-hop-6-loai-thuc-pham-tot-cho-phoi-co-the-ban-chua-biet-201910031631114959-640x400.jpg" class="attachment-medium size-medium wp-post-image" alt="" sizes="(max-width: 640px) 100vw, 640px" /> </div>
                                                            </div>
                                                            <!-- .box-image -->
                                                            <div class="box-text text-left is-small">
                                                                <div class="box-text-inner blog-post-inner">
                                                                    <h5 class="post-title is-large ">Bổ sung 6 loại thực phẩm, gia vị này vào thực đơn để thanh lọc, giải độc cho phổi</h5>
                                                                    <div class="is-divider"></div>
                                                                </div>
                                                                <!-- .box-text-inner -->
                                                            </div>
                                                            <!-- .box-text -->
                                                        </div>
                                                        <!-- .box -->
                                                    </a>
                                                    <!-- .link -->
                                                </div>
                                                <!-- .col-inner -->
                                            </div>
                                            <!-- .col -->
                                            <div class="col post-item">
                                                <div class="col-inner">
                                                    <a href="#" class="plain">
                                                        <div class="box box-vertical box-text-bottom box-blog-post has-hover">
                                                            <div class="box-image" style="width:26%;">
                                                                <div class="image-cover" style="padding-top:56.25%;">
                                                                    <img width="640" height="400" src="img/new/tong-hop-6-loai-thuc-pham-tot-cho-phoi-co-the-ban-chua-biet-201910031631114959-640x400.jpg" class="attachment-medium size-medium wp-post-image" alt="" sizes="(max-width: 640px) 100vw, 640px" /> </div>
                                                            </div>
                                                            <!-- .box-image -->
                                                            <div class="box-text text-left is-small">
                                                                <div class="box-text-inner blog-post-inner">
                                                                    <h5 class="post-title is-large ">Bổ sung 6 loại thực phẩm, gia vị này vào thực đơn để thanh lọc, giải độc cho phổi</h5>
                                                                    <div class="is-divider"></div>
                                                                </div>
                                                                <!-- .box-text-inner -->
                                                            </div>
                                                            <!-- .box-text -->
                                                        </div>
                                                        <!-- .box -->
                                                    </a>
                                                    <!-- .link -->
                                                </div>
                                                <!-- .col-inner -->
                                            </div>
                                            <!-- .col -->
                                            <div class="col post-item">
                                                <div class="col-inner">
                                                    <a href="#" class="plain">
                                                        <div class="box box-vertical box-text-bottom box-blog-post has-hover">
                                                            <div class="box-image" style="width:26%;">
                                                                <div class="image-cover" style="padding-top:56.25%;">
                                                                    <img width="640" height="400" src="img/new/tong-hop-6-loai-thuc-pham-tot-cho-phoi-co-the-ban-chua-biet-201910031631114959-640x400.jpg" class="attachment-medium size-medium wp-post-image" alt="" sizes="(max-width: 640px) 100vw, 640px" /> </div>
                                                            </div>
                                                            <!-- .box-image -->
                                                            <div class="box-text text-left is-small">
                                                                <div class="box-text-inner blog-post-inner">
                                                                    <h5 class="post-title is-large ">Bổ sung 6 loại thực phẩm, gia vị này vào thực đơn để thanh lọc, giải độc cho phổi</h5>
                                                                    <div class="is-divider"></div>
                                                                </div>
                                                                <!-- .box-text-inner -->
                                                            </div>
                                                            <!-- .box-text -->
                                                        </div>
                                                        <!-- .box -->
                                                    </a>
                                                    <!-- .link -->
                                                </div>
                                                <!-- .col-inner -->
                                            </div>
                                            <!-- .col -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row large-columns-5 medium-columns-4 small-columns-2 row-collapse slider row-slider slider-nav-simple slider-nav-push" data-flickity-options='{"imagesLoaded": true, "groupCells": "100%", "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": false, "rightToLeft": false, "autoPlay" : 3000}'>

                            </div>
                        </div>
                    </div>
                    <style scope="scope">
                    </style>
                </div>
            </div>
        </div>

        <style scope="scope">
        </style>
    </div>
</div>